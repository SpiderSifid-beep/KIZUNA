# Architecture — Phase 1

```text
Browser / PWA-ready web client
        | REST (JWT) + Socket.IO
        v
NestJS API  ---- Prisma ORM ---- PostgreSQL
        |
        +---- Redis (reserved for presence, rate limits, pub/sub)
        |
        +---- Future adapters: S3, FCM/APNs, WebRTC SFU, AI provider
```

## Boundaries
- Auth module owns account creation and token issuance.
- Chat module owns membership checks, conversation queries, and message persistence.
- Socket gateway authenticates the handshake and checks conversation membership before joining rooms or sending messages.
- Prisma schema is the source of truth for relational data.

## Next implementation increments
1. Refresh-token rotation, email/phone verification, rate limiting, account/device sessions.
2. Media upload pipeline using signed S3 URLs and malware/content checks.
3. Groups/channels, roles, moderation and audit logs.
4. Story service and media processing.
5. WebRTC using a managed SFU (e.g. LiveKit) rather than a hand-built media server.
6. Push notifications (FCM/APNs), offline queue and PWA service worker.
7. Mobile app with React Native / Expo sharing API contracts.
8. E2EE using an audited protocol/library; do not invent cryptography.
