# API quick reference

Base URL: `http://localhost:4000`

- `POST /auth/register` — `{ email, username, displayName, password }`
- `POST /auth/login` — `{ email, password }`
- `GET /chat/conversations` — Bearer token required
- `POST /chat/conversations` — `{ email }`, creates or returns a direct conversation
- `GET /chat/conversations/:id/messages` — Bearer token required
- `POST /chat/conversations/:id/messages` — `{ body }`, Bearer token required

Socket namespace: `/chat`
- Handshake auth: `{ token: "<JWT>" }`
- `join`: `{ conversationId }`
- `send`: `{ conversationId, body }`
- Server event `message`: persisted message object
