# KIZUNA Android app
Expo React Native Android client with Persian RTL-style login/register screens, conversation list, chat view and local preview mode.

## Build APK (cloud)
Install Node.js and EAS CLI (`npm i -g eas-cli`), sign in (`eas login`), then from this folder run `eas build --platform android --profile preview`. The first build needs an Expo account and internet access.

## Backend
Deploy the NestJS API from `apps/api`, then replace `https://YOUR_API_HOST` in `App.tsx` with its HTTPS origin. Until that is done, use the preview button; it demonstrates the UI but does not deliver messages between devices.
