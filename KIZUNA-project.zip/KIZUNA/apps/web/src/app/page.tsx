'use client';
import { useEffect, useMemo, useState } from 'react';
import { io, Socket } from 'socket.io-client';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
const SOCKET = process.env.NEXT_PUBLIC_SOCKET_URL || API;
type User = { id:string; email:string; username:string; displayName:string };
type Message = { id:string; body:string; senderId:string; createdAt:string; sender?:{displayName:string;username:string} };
type Conversation = { id:string; members:{user:User}[]; messages:Message[] };

export default function Home() {
  const [token,setToken] = useState('');
  const [me,setMe] = useState<User|null>(null);
  const [mode,setMode] = useState<'login'|'register'>('register');
  const [form,setForm] = useState({email:'',username:'',displayName:'',password:''});
  const [conversations,setConversations] = useState<Conversation[]>([]);
  const [active,setActive] = useState('');
  const [messages,setMessages] = useState<Message[]>([]);
  const [draft,setDraft] = useState('');
  const [peerEmail,setPeerEmail] = useState('');
  const [error,setError] = useState('');
  const [socket,setSocket] = useState<Socket|null>(null);

  const activeConversation = useMemo(()=>conversations.find(c=>c.id===active),[conversations,active]);
  async function request(path:string, method='GET', body?:unknown) {
    const res = await fetch(`${API}${path}`, { method, headers:{'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`}:{})}, ...(body?{body:JSON.stringify(body)}:{}) });
    const data = await res.json().catch(()=>({message:'Unexpected server response'}));
    if (!res.ok) throw new Error(data.message || 'Request failed');
    return data;
  }
  async function authenticate(e:React.FormEvent) {
    e.preventDefault(); setError('');
    try {
      const data = await fetch(`${API}/auth/${mode}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.message||'ورود ناموفق بود');return d;});
      setToken(data.accessToken); setMe(data.user);
    } catch(err:any) { setError(Array.isArray(err.message)?err.message.join('، '):err.message); }
  }
  useEffect(()=>{ if(!token)return; request('/chat/conversations').then(setConversations).catch(e=>setError(e.message)); },[token]);
  useEffect(()=>{
    if(!token)return;
    const s=io(`${SOCKET}/chat`,{auth:{token},transports:['websocket','polling']});
    s.on('message',(m:Message)=>setMessages(prev=>prev.some(x=>x.id===m.id)?prev:[...prev,m]));
    setSocket(s); return ()=>{s.disconnect();setSocket(null);};
  },[token]);
  useEffect(()=>{
    if(!active || !socket)return;
    socket.emit('join',{conversationId:active});
    request(`/chat/conversations/${active}/messages`).then(setMessages).catch(e=>setError(e.message));
  },[active,socket]);
  async function createChat(e:React.FormEvent) {
    e.preventDefault(); setError('');
    try { const c=await request('/chat/conversations','POST',{email:peerEmail}); setPeerEmail(''); const list=await request('/chat/conversations');setConversations(list);setActive(c.id); }
    catch(e:any){setError(e.message);}
  }
  function send(e:React.FormEvent) {
    e.preventDefault(); if(!draft.trim()||!active||!socket)return;
    socket.emit('send',{conversationId:active,body:draft.trim()},(ack:any)=>{if(!ack?.ok)setError('ارسال پیام انجام نشد؛ اتصال را بررسی کن.');});
    setDraft('');
  }
  if(!token) return <main className="min-h-screen grid place-items-center p-5"><section className="glass w-full max-w-md rounded-3xl p-7 shadow-2xl shadow-violet-950/30">
    <div className="mb-7 text-center"><div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-violet-500/20 text-3xl">✦</div><h1 className="text-3xl font-black">NOVA</h1><p className="mt-2 text-sm text-violet-200/70">ارتباطی فراتر از پیام</p></div>
    <div className="mb-5 grid grid-cols-2 rounded-xl bg-black/30 p-1"><button onClick={()=>setMode('register')} className={`rounded-lg p-2 ${mode==='register'?'bg-violet-500 text-white':''}`}>ثبت‌نام</button><button onClick={()=>setMode('login')} className={`rounded-lg p-2 ${mode==='login'?'bg-violet-500 text-white':''}`}>ورود</button></div>
    <form onSubmit={authenticate} className="space-y-3">
      {mode==='register'&&<><input required placeholder="نام نمایشی" className="w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400" value={form.displayName} onChange={e=>setForm({...form,displayName:e.target.value})}/><input required minLength={3} placeholder="نام کاربری" className="w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400" value={form.username} onChange={e=>setForm({...form,username:e.target.value})}/></>}
      <input required type="email" placeholder="ایمیل" className="w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
      <input required type="password" minLength={mode==='register'?10:1} placeholder="رمز عبور" className="w-full rounded-xl border border-white/10 bg-black/30 p-3 outline-none focus:border-violet-400" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
      {error&&<p className="text-sm text-rose-300">{error}</p>}
      <button className="w-full rounded-xl bg-gradient-to-l from-violet-600 to-fuchsia-500 p-3 font-bold shadow-lg shadow-violet-900/30">{mode==='register'?'ساخت حساب':'ورود به حساب'}</button>
    </form><p className="mt-5 text-center text-xs leading-6 text-white/40">نسخه آغازین — فعلاً احراز هویت با ایمیل و رمز عبور</p>
  </section></main>;
  return <main className="min-h-screen p-3 md:p-6"><header className="glass mb-4 flex items-center justify-between rounded-2xl p-4"><div><div className="text-xl font-black tracking-widest">NOVA <span className="text-violet-300">✦</span></div><div className="text-xs text-white/45">فضای ارتباطی تو</div></div><div className="text-sm text-white/70">{me?.displayName} <button onClick={()=>{setToken('');setMe(null);setMessages([]);}} className="mr-3 rounded-lg border border-white/10 px-3 py-1.5">خروج</button></div></header>
    <div className="grid min-h-[78vh] gap-4 md:grid-cols-[320px_1fr]">
      <aside className="glass rounded-2xl p-4"><h2 className="mb-4 font-bold">گفتگوها</h2><form onSubmit={createChat} className="mb-4 flex gap-2"><input type="email" required value={peerEmail} onChange={e=>setPeerEmail(e.target.value)} placeholder="ایمیل مخاطب" className="min-w-0 flex-1 rounded-xl bg-black/30 p-2 text-sm outline-none"/><button className="rounded-xl bg-violet-600 px-3">+</button></form>
        <div className="space-y-2">{conversations.map(c=>{const other=c.members.find(m=>m.user.id!==me?.id)?.user;return <button key={c.id} onClick={()=>setActive(c.id)} className={`w-full rounded-xl p-3 text-right ${active===c.id?'bg-violet-500/20 ring-1 ring-violet-400/40':'bg-white/[.03] hover:bg-white/[.07]'}`}><div className="font-semibold">{other?.displayName||'گفتگوی شخصی'}</div><div className="truncate text-xs text-white/40">{c.messages?.[0]?.body||other?.email}</div></button>})}</div>
      </aside>
      <section className="glass flex min-h-[65vh] flex-col rounded-2xl p-4">
        {activeConversation?<><div className="border-b border-white/10 pb-3 font-bold">{activeConversation.members.find(m=>m.user.id!==me?.id)?.user.displayName||'گفتگو'}</div><div className="flex-1 space-y-3 overflow-y-auto py-4">{messages.map(m=><div key={m.id} className={`max-w-[82%] rounded-2xl px-4 py-3 ${m.senderId===me?.id?'mr-auto bg-violet-600/30':'ml-auto bg-white/[.07]'}`}><div className="mb-1 text-[10px] text-violet-200/60">{m.sender?.displayName|| (m.senderId===me?.id?'شما':'مخاطب')}</div><p className="whitespace-pre-wrap break-words text-sm">{m.body}</p><div className="mt-1 text-left text-[10px] text-white/35">{new Date(m.createdAt).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}</div></div>)}</div><form onSubmit={send} className="flex gap-2 border-t border-white/10 pt-3"><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="پیامت را بنویس..." className="min-w-0 flex-1 rounded-xl bg-black/30 p-3 outline-none focus:ring-1 focus:ring-violet-400"/><button className="rounded-xl bg-violet-600 px-5 font-bold">ارسال</button></form></>:<div className="grid flex-1 place-items-center text-center text-white/40"><div><div className="mb-3 text-5xl">✧</div><p>یک گفتگو انتخاب کن یا گفتگوی تازه بساز.</p></div></div>}
        {error&&<p className="mt-3 text-sm text-rose-300">{error}</p>}
      </section>
    </div>
  </main>;
}
