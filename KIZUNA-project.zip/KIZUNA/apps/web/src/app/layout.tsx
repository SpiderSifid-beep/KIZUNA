import './globals.css';
export const metadata = { title: 'KIZUNA — Messenger', description: 'A modern social messenger' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="fa" dir="rtl"><body>{children}</body></html>;
}
