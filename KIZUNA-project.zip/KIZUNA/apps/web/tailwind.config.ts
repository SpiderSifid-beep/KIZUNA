import type { Config } from 'tailwindcss';
export default { content: ['./src/**/*.{js,ts,jsx,tsx}'], theme: { extend: { colors: { ink:'#09070f', panel:'#15111f', violet:'#9b72ff' } } }, plugins: [] } satisfies Config;
