import { UseGuards } from '@nestjs/common';
import { ConnectedSocket, MessageBody, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { JwtService } from '@nestjs/jwt';
import { Server, Socket } from 'socket.io';
import { ChatService } from './chat.service';

@WebSocketGateway({ cors: { origin: process.env.WEB_ORIGIN?.split(',') ?? ['http://localhost:3000'] }, namespace: '/chat' })
export class ChatGateway {
  @WebSocketServer() server: Server;
  constructor(private jwt: JwtService, private chat: ChatService) {}
  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth?.token;
      if (!token) return client.disconnect();
      const payload = await this.jwt.verifyAsync(token);
      client.data.userId = payload.sub;
    } catch { client.disconnect(); }
  }
  @SubscribeMessage('join')
  async join(@ConnectedSocket() client: Socket, @MessageBody() data: { conversationId: string }) {
    try { await this.chat.assertMember(client.data.userId, data.conversationId); client.join(data.conversationId); return { ok: true }; }
    catch { return { ok: false }; }
  }
  @SubscribeMessage('send')
  async send(@ConnectedSocket() client: Socket, @MessageBody() data: { conversationId: string; body: string }) {
    if (!data?.body?.trim() || data.body.length > 5000) return { ok: false };
    try {
      const message = await this.chat.send(client.data.userId, data.conversationId, data.body.trim());
      this.server.to(data.conversationId).emit('message', message);
      return { ok: true, message };
    } catch { return { ok: false }; }
  }
}
