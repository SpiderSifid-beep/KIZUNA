import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { IsEmail, IsString, MinLength, MaxLength } from 'class-validator';
import { JwtStrategyGuard } from './jwt.guard';
import { ChatService } from './chat.service';
class CreateConversationDto { @IsEmail() email: string; }
class SendMessageDto { @IsString() @MinLength(1) @MaxLength(5000) body: string; }
@Controller('chat')
@UseGuards(JwtStrategyGuard)
export class ChatController {
  constructor(private chat: ChatService) {}
  @Get('conversations') list(@Req() req: any) { return this.chat.list(req.user.id); }
  @Post('conversations') create(@Req() req: any, @Body() dto: CreateConversationDto) { return this.chat.createConversation(req.user.id, dto.email); }
  @Get('conversations/:id/messages') messages(@Req() req: any, @Param('id') id: string) { return this.chat.messages(req.user.id, id); }
  @Post('conversations/:id/messages') async send(@Req() req: any, @Param('id') id: string, @Body() dto: SendMessageDto) { return this.chat.send(req.user.id, id, dto.body); }
}
