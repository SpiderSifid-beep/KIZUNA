import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaService } from './prisma.service';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { ChatController } from './chat.controller';
import { ChatService } from './chat.service';
import { JwtStrategyGuard } from './jwt.guard';
import { ChatGateway } from './chat.gateway';

@Module({
  imports: [JwtModule.register({ secret: process.env.JWT_SECRET ?? 'development-only-change-me', signOptions: { expiresIn: '2h' } })],
  controllers: [AuthController, ChatController],
  providers: [PrismaService, AuthService, ChatService, JwtStrategyGuard, ChatGateway],
})
export class AppModule {}
