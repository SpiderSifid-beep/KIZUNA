import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from './prisma.service';
@Injectable()
export class ChatService {
  constructor(private db: PrismaService) {}
  async createConversation(userId: string, email: string) {
    const other = await this.db.user.findUnique({ where: { email: email.toLowerCase() } });
    if (!other || other.id === userId) throw new NotFoundException('User not found');
    const existing = await this.db.conversation.findFirst({
      where: { isGroup: false, AND: [{ members: { some: { userId } } }, { members: { some: { userId: other.id } } }] }
    });
    if (existing) return existing;
    return this.db.conversation.create({ data: { members: { create: [{ userId }, { userId: other.id }] } } });
  }
  async list(userId: string) {
    return this.db.conversation.findMany({
      where: { members: { some: { userId } } },
      include: { members: { include: { user: { select: { id:true, email:true, username:true, displayName:true } } } },
        messages: { take: 1, orderBy: { createdAt: 'desc' } } },
      orderBy: { updatedAt: 'desc' }
    });
  }
  async messages(userId: string, conversationId: string) {
    await this.assertMember(userId, conversationId);
    return this.db.message.findMany({ where: { conversationId }, include: { sender: { select: { id:true, username:true, displayName:true } } }, orderBy: { createdAt: 'asc' }, take: 100 });
  }
  async send(userId: string, conversationId: string, body: string) {
    await this.assertMember(userId, conversationId);
    const msg = await this.db.message.create({ data: { senderId: userId, conversationId, body }, include: { sender: { select: { id:true, username:true, displayName:true } } } });
    await this.db.conversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } });
    return msg;
  }
  async assertMember(userId: string, conversationId: string) {
    const member = await this.db.conversationMember.findUnique({ where: { userId_conversationId: { userId, conversationId } } });
    if (!member) throw new ForbiddenException('Not a conversation member');
  }
}
