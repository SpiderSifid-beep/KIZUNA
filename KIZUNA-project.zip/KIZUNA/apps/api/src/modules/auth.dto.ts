import { IsEmail, IsString, MinLength, MaxLength, Matches } from 'class-validator';
export class RegisterDto {
  @IsEmail() email: string;
  @IsString() @MinLength(3) @MaxLength(24) @Matches(/^[a-zA-Z0-9_]+$/) username: string;
  @IsString() @MinLength(2) @MaxLength(48) displayName: string;
  @IsString() @MinLength(10) @MaxLength(72) password: string;
}
export class LoginDto {
  @IsEmail() email: string;
  @IsString() @MinLength(1) password: string;
}
