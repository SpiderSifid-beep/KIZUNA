import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from './prisma.service';
import { LoginDto, RegisterDto } from './auth.dto';

@Injectable()
export class AuthService {
  constructor(private db: PrismaService, private jwt: JwtService) {}
  async register(dto: RegisterDto) {
    const exists = await this.db.user.findFirst({ where: { OR: [{ email: dto.email.toLowerCase() }, { username: dto.username }] } });
    if (exists) throw new ConflictException('Email or username is already in use');
    const passwordHash = await bcrypt.hash(dto.password, 12);
    const user = await this.db.user.create({ data: { email: dto.email.toLowerCase(), username: dto.username, displayName: dto.displayName, passwordHash }, select: { id: true, email: true, username: true, displayName: true } });
    return this.issue(user);
  }
  async login(dto: LoginDto) {
    const user = await this.db.user.findUnique({ where: { email: dto.email.toLowerCase() } });
    if (!user || !(await bcrypt.compare(dto.password, user.passwordHash))) throw new UnauthorizedException('Invalid email or password');
    return this.issue({ id: user.id, email: user.email, username: user.username, displayName: user.displayName });
  }
  private issue(user: {id:string; email:string; username:string; displayName:string}) {
    const accessToken = this.jwt.sign({ sub: user.id, email: user.email });
    return { accessToken, user };
  }
}
