# KIZUNA Messenger — Phase 1 starter

A runnable, modular monorepo starter for a Persian-first social messenger.
This is a **working foundation**, not a claim that every feature in the long specification is already implemented.

## Included in this phase
- Next.js + TypeScript + Tailwind web client (RTL-first)
- NestJS API with JWT registration/login and authenticated conversation/message endpoints
- Socket.IO gateway for live message delivery
- PostgreSQL schema and Prisma migrations workflow
- Redis service reserved for sessions, presence, and scaling
- Docker Compose for local PostgreSQL and Redis
- Environment template and API notes

## Not included yet
Native Android/iOS builds, production-grade E2E encryption, WebRTC calling, stories, channels, bots, AI integrations, push notifications, S3 uploads, and production moderation are future phases. External credentials and infrastructure are required for those features. Do not expose this starter to the public internet without security review.

## Requirements
- Node.js 20+
- npm 10+
- Docker Desktop (or Docker Engine + Compose)

## Run locally
1. Copy `.env.example` to `.env` in the project root.
2. Start infrastructure:
   ```bash
   docker compose up -d
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Generate Prisma client and apply the schema:
   ```bash
   npm run db:generate
   npm run db:push
   ```
5. Start API and web client:
   ```bash
   npm run dev
   ```
6. Open http://localhost:3000. API runs at http://localhost:4000.

## First use
Register two accounts in separate browser sessions. Create a conversation by entering the other user's exact email from the web interface, then send messages.

## Environment
See `.env.example`. Replace all development secrets before any deployment. In production, use a managed secret store, HTTPS, database backups, rate limiting at the edge, email/SMS verification, and security monitoring.

## Project layout
- `apps/web` — Next.js web application
- `apps/api` — NestJS REST + Socket.IO API
- `packages/shared` — shared types
- `infra` — local infrastructure
- `docs` — architecture and API notes

## Commands
- `npm run dev` — run API and web concurrently
- `npm run build` — build workspaces
- `npm run db:generate` — generate Prisma client
- `npm run db:push` — apply Prisma schema to local database
- `npm run lint` — lint workspaces

## Security notes
Passwords are hashed with bcrypt. Access tokens are short-lived JWTs. This starter does not yet implement refresh-token rotation, verified email/phone flows, passkeys, device management, abuse prevention, or E2EE. Message transport uses TLS only when deployed behind HTTPS/WSS; database-at-rest encryption is an infrastructure responsibility.
